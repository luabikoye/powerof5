<div class="navbar-default sidebar" role="navigation" style="margin-top:100px;">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            
                        </li>
                        
                       
                        
                         <li>
                            <a href="add_user.php"><i class="fa fa-user fa-fw"></i>New Users</a>
                           
                        </li>
                         
                        
                         <li>
                            <a href="#"><i class="fa fa-users fa-fw"></i>Registered Users<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="registered_members.php?status=pending">Pending Members </a></li>
                                <li>
                                    <a href="registered_members.php">Total Active Members </a></li>
                                <li>
                                    <a href="registered_members.php?plan=classic">Classic Members </a></li>
                                <li>
                                    <a href="registered_members.php?plan=premium">Premium Members </a></li>
                                <li>
                                    <a href="registered_members.php?suspended=yes">Suspended Members </a></li>
                                    
                                 
                            </ul>
                           
                        </li>
                        
                        
                         
                        
                         <li>
                            <a href="#"><i class="fa fa-money fa-fw"></i>Payments<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="pending_payments.php?status=unpaid">Pending Payment Requests </a></li>
                                <li>
                                    <a href="pending_payments.php?status=paid">Closed Payment Requests</a></li>
                                
                                    
                                 
                            </ul>
                           
                        </li>
                        
                       
                        <!-- /.nav-second-level 
                      

                        <li>
                            <a href="login.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                         
                        </li>
                    </ul>
               
            </div>
                <!-- /.sidebar-collapse -->
            <!-- /.navbar-static-side -->
        </nav>

$(document).ready(function () {
	
	$('#change_dp').click(function(){
			$('#passport').slideDown(100);
		})

});
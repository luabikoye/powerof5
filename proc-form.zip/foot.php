<footer>
 <div class="container">
 <div class="row align">
 
 
 
 
 <div class="col-md-3 col-sm-4 col-xs-6 ">
<h2><strong>Contact Information</strong></h2>
<p style="color:#FFF">148 Lagos Road, Ikorodu,<br>Lagos Nigeria <br>
<i class="glyphicon glyphicon-earphone" aria-hidden="true"></i> 090 34965851, 080 38139987<br><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i> info@powerof5ng.com
<br><i class="glyphicon glyphicon-globe" aria-hidden="true"></i> www.powerof5ng.com<br><br></p>
</div>
 
 
 
 
 
 <div class="col-md-3 col-sm-4 col-xs-6">
 <h2><strong>Quick Link</strong></h2>
<p><a href="index.php">Home</a></p>
<p><a href="about.php">Abouts Us</a></p>
<p><a href="how-it-works.php">How It Works</a></p>
<p><a href="faq.php">FAQ</a></p>
<p><a href="contact-us.php">Contact Us</a></p>
<p><a href="form.php">Sign Up/Login</a></p>
</div>





 
 <div class="col-md-3 col-sm-4 col-xs-6">
 <h2><strong>ACCEPTED CARDS</strong></h2>
 <img src="images/pp.png" alt="">
 <div class="socials" style="padding-top:20px;">
<a href="https://www.facebook.com/Gman-Africa-1721230254856565/" target="_blank"><i class="fa fa-facebook"></i></a>
<a href="https://twitter.com/gmanafrica" target="_blank"><i class="fa fa-twitter"></i></a>
</div>
</div>


<div class="col-md-3 col-sm-4 col-xs-6">
<h2><strong>CONNECT WITH US</strong></h2>
 <a class="twitter-timeline" data-height="250" data-theme="light" data-link-color="#eb8823" href="https://twitter.com/powerof5">Tweets by powerof5</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
    
 
</div>
 

                            </div>
</div>

 </div>
 
 </footer>
 
 <div class="container-fluid copyright">
 <p>©  Copyright  Powerof5  <?php echo date ('Y') ?> |  All Rights Reserved | Design by<a href="" target="_blank"> </a></p>

 </div>